import { Component } from "react";
import "./index.css"

class Footer extends Component{
    render(){
        return(
            <div className="fun footer" id="contact" >
                <h3>Developed by <a href="https://www.linkedin.com/in/yasaswini-jakkula-a74413226/" className="links">@Yasaswini</a> &copy; all rights reserved</h3>
            </div>
        )
    }
}

export default Footer